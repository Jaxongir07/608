let admin = 'Alex'
let name = 'Alex'



console.log(admin);



/////
let balance = 25000

let car = 4480
let food = 890


let invoice = 5500
let stock = 4200

console.log(balance - car - food + invoice + stock)